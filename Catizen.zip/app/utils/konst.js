const DIR_PATH_SESSION = "catizen-session";
export { DIR_PATH_SESSION };
